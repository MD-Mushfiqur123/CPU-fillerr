"""Compute module"""



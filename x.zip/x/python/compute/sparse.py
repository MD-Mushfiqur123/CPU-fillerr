"""Sparse matrix operations"""
import numpy as np
from scipy import sparse

class SparseMatrixOps:
    """Sparse matrix operations"""
    
    @staticmethod
    def create_sparse(size: int, density: float = 0.1):
        """Create sparse matrix"""
        return sparse.random(size, size, density=density, format='csr')
    
    @staticmethod
    def sparse_multiply(a: sparse.spmatrix, b: sparse.spmatrix):
        """Sparse matrix multiplication"""
        return a.dot(b)
    
    @staticmethod
    def sparse_solve(a: sparse.spmatrix, b: np.ndarray):
        """Solve sparse linear system"""
        from scipy.sparse.linalg import spsolve
        return spsolve(a, b)



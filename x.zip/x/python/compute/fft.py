"""Fast Fourier Transform computations"""
import numpy as np
from scipy import fft

class FFTProcessor:
    """FFT processing"""
    
    @staticmethod
    def compute_fft(signal: np.ndarray) -> np.ndarray:
        """Compute FFT"""
        return fft.fft(signal)
    
    @staticmethod
    def compute_2d_fft(matrix: np.ndarray) -> np.ndarray:
        """2D FFT"""
        return fft.fft2(matrix)
    
    @staticmethod
    def compute_fft_batch(signals: np.ndarray) -> np.ndarray:
        """Batch FFT computation"""
        return np.array([fft.fft(s) for s in signals])



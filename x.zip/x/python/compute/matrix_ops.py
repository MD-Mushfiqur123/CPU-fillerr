"""Matrix operations"""
import numpy as np
from scipy import linalg
from typing import Tuple

class MatrixCalculator:
    """High-performance matrix operations"""
    
    @staticmethod
    def multiply_large_matrices(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Multiply large matrices efficiently"""
        return np.dot(a, b)
    
    @staticmethod
    def eigendecomposition(matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Compute eigenvalues and eigenvectors"""
        return linalg.eig(matrix)
    
    @staticmethod
    def svd_decomposition(matrix: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
        """Singular value decomposition"""
        return linalg.svd(matrix)
    
    @staticmethod
    def cholesky_decomposition(matrix: np.ndarray) -> np.ndarray:
        """Cholesky decomposition"""
        return linalg.cholesky(matrix)
    
    @staticmethod
    def matrix_inverse(matrix: np.ndarray) -> np.ndarray:
        """Matrix inversion"""
        return linalg.inv(matrix)



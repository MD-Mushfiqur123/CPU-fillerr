"""Numerical computations"""
import numpy as np
from scipy import integrate, optimize
from typing import Callable

class NumericalSolver:
    """Numerical solving methods"""
    
    @staticmethod
    def integrate_function(func: Callable, a: float, b: float) -> float:
        """Numerical integration"""
        return integrate.quad(func, a, b)[0]
    
    @staticmethod
    def optimize_function(func: Callable, bounds: tuple) -> dict:
        """Function optimization"""
        result = optimize.minimize(func, x0=[0.5], bounds=[bounds])
        return result
    
    @staticmethod
    def solve_ode(func: Callable, t_span: tuple, y0: list) -> np.ndarray:
        """Solve ordinary differential equation"""
        return integrate.odeint(func, y0, np.linspace(*t_span, 1000))



"""Simulation computations"""
import numpy as np
from typing import Callable

class MonteCarloSimulator:
    """Monte Carlo simulation"""
    
    @staticmethod
    def simulate(n_samples: int = 1000000, dim: int = 10) -> float:
        """Run Monte Carlo simulation"""
        samples = np.random.randn(n_samples, dim)
        # Compute some expensive operation
        result = np.sum(np.exp(-np.sum(samples**2, axis=1)))
        return result / n_samples
    
    @staticmethod
    def pi_estimation(n_samples: int = 10000000) -> float:
        """Estimate pi using Monte Carlo"""
        x = np.random.rand(n_samples)
        y = np.random.rand(n_samples)
        inside = np.sum(x**2 + y**2 <= 1.0)
        return 4.0 * inside / n_samples



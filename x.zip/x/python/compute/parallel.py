"""Parallel computing"""
import multiprocessing as mp
import numpy as np
from typing import Callable, List
from concurrent.futures import ProcessPoolExecutor

class ParallelProcessor:
    """Parallel processing utilities"""
    
    def __init__(self, n_workers: int = None):
        self.n_workers = n_workers or mp.cpu_count()
    
    def parallel_map(self, func: Callable, items: List) -> List:
        """Apply function to items in parallel"""
        with ProcessPoolExecutor(max_workers=self.n_workers) as executor:
            return list(executor.map(func, items))
    
    def parallel_compute(self, computations: List[Callable]) -> List:
        """Execute computations in parallel"""
        with ProcessPoolExecutor(max_workers=self.n_workers) as executor:
            futures = [executor.submit(comp) for comp in computations]
            return [f.result() for f in futures]



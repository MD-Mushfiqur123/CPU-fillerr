"""Data processing"""
import pandas as pd
import numpy as np
from typing import List, Dict

class DataProcessor:
    """Process and transform data"""
    
    @staticmethod
    def process_dataframe(df: pd.DataFrame) -> pd.DataFrame:
        """Process dataframe"""
        df = df.fillna(0)
        df = df.astype(np.float32)
        return df
    
    @staticmethod
    def normalize_data(data: np.ndarray) -> np.ndarray:
        """Normalize data"""
        mean = np.mean(data, axis=0)
        std = np.std(data, axis=0)
        return (data - mean) / (std + 1e-8)
    
    @staticmethod
    def augment_data(data: np.ndarray, n_augment: int = 10) -> np.ndarray:
        """Data augmentation"""
        augmented = []
        for _ in range(n_augment):
            noise = np.random.randn(*data.shape) * 0.1
            augmented.append(data + noise)
        return np.concatenate(augmented, axis=0)



"""Data processing module"""



"""CUDA GPU computing"""
import cupy as cp
import numpy as np
from typing import Tuple

class CUDACalculator:
    """GPU-accelerated calculations using CuPy"""
    
    def __init__(self):
        if not cp.cuda.is_available():
            raise RuntimeError("CUDA not available")
        self.device = cp.cuda.Device()
    
    def matrix_multiply(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Matrix multiplication on GPU"""
        a_gpu = cp.asarray(a)
        b_gpu = cp.asarray(b)
        result_gpu = cp.dot(a_gpu, b_gpu)
        return cp.asnumpy(result_gpu)
    
    def elementwise_operations(self, arr: np.ndarray) -> np.ndarray:
        """Perform elementwise operations on GPU"""
        arr_gpu = cp.asarray(arr)
        result = cp.sin(arr_gpu) * cp.cos(arr_gpu) + cp.sqrt(cp.abs(arr_gpu))
        return cp.asnumpy(result)
    
    def parallel_reduce(self, arr: np.ndarray) -> float:
        """Parallel reduction on GPU"""
        arr_gpu = cp.asarray(arr)
        return float(cp.sum(arr_gpu))



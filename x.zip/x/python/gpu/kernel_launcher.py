"""GPU kernel launcher"""
import pycuda.driver as cuda
import pycuda.autoinit
from pycuda.compiler import SourceModule
import numpy as np

class KernelLauncher:
    """Launch CUDA kernels"""
    
    def __init__(self):
        self.mod = None
    
    def compile_kernel(self, kernel_code: str):
        """Compile CUDA kernel"""
        self.mod = SourceModule(kernel_code)
    
    def vector_add(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Vector addition on GPU"""
        kernel = self.mod.get_function("vector_add")
        a_gpu = cuda.mem_alloc(a.nbytes)
        b_gpu = cuda.mem_alloc(b.nbytes)
        c_gpu = cuda.mem_alloc(a.nbytes)
        
        cuda.memcpy_htod(a_gpu, a)
        cuda.memcpy_htod(b_gpu, b)
        
        kernel(a_gpu, b_gpu, c_gpu, block=(256, 1, 1), grid=(len(a)//256 + 1, 1))
        
        c = np.empty_like(a)
        cuda.memcpy_dtoh(c, c_gpu)
        return c



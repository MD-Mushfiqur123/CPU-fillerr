"""GPU computing module"""



"""OpenCL GPU computing"""
import pyopencl as cl
import numpy as np
from typing import Tuple

class OpenCLCalculator:
    """GPU computing using OpenCL"""
    
    def __init__(self):
        self.ctx = cl.create_some_context()
        self.queue = cl.CommandQueue(self.ctx)
        self.program = None
    
    def load_kernel(self, kernel_code: str):
        """Load OpenCL kernel"""
        self.program = cl.Program(self.ctx, kernel_code).build()
    
    def vector_add(self, a: np.ndarray, b: np.ndarray) -> np.ndarray:
        """Vector addition on GPU"""
        mf = cl.mem_flags
        a_buf = cl.Buffer(self.ctx, mf.READ_ONLY | mf.COPY_HOST_PTR, hostbuf=a)
        b_buf = cl.Buffer(self.ctx, mf.READ_ONLY | mf.COPY_HOST_PTR, hostbuf=b)
        dest_buf = cl.Buffer(self.ctx, mf.WRITE_ONLY, b.nbytes)
        
        self.program.vector_add(self.queue, a.shape, None, a_buf, b_buf, dest_buf)
        result = np.empty_like(a)
        cl.enqueue_copy(self.queue, result, dest_buf)
        return result



"""Tensor operations on GPU"""
import torch
import numpy as np
from typing import List

class GPUTensorOps:
    """GPU tensor operations using PyTorch"""
    
    def __init__(self, device: str = 'cuda'):
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
    
    def create_random_tensor(self, shape: tuple, requires_grad: bool = False) -> torch.Tensor:
        """Create random tensor on GPU"""
        return torch.randn(shape, device=self.device, requires_grad=requires_grad)
    
    def batch_matmul(self, tensors: List[torch.Tensor]) -> torch.Tensor:
        """Batch matrix multiplication"""
        result = tensors[0].to(self.device)
        for t in tensors[1:]:
            result = torch.matmul(result, t.to(self.device))
        return result
    
    def convolve_3d(self, input_tensor: torch.Tensor, kernel: torch.Tensor) -> torch.Tensor:
        """3D convolution on GPU"""
        return torch.nn.functional.conv3d(
            input_tensor.to(self.device),
            kernel.to(self.device),
            padding=1
        )



"""Custom exceptions"""
class ComputeError(Exception):
    """Base compute error"""
    pass

class GPUError(ComputeError):
    """GPU-related error"""
    pass

class WorkerError(ComputeError):
    """Worker process error"""
    pass

class DataError(ComputeError):
    """Data processing error"""
    pass



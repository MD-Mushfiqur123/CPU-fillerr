"""Configuration management"""
import os
from typing import Dict, Any

class Config:
    """Global configuration"""
    CPU_CORES = os.cpu_count() or 8
    GPU_ENABLED = os.getenv('GPU_ENABLED', 'true').lower() == 'true'
    BATCH_SIZE = int(os.getenv('BATCH_SIZE', '1024'))
    MAX_WORKERS = int(os.getenv('MAX_WORKERS', str(CPU_CORES * 2)))
    
    REDIS_HOST = os.getenv('REDIS_HOST', 'localhost')
    REDIS_PORT = int(os.getenv('REDIS_PORT', '6379'))
    
    DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://localhost/compute')
    
    @classmethod
    def get_all(cls) -> Dict[str, Any]:
        """Get all configuration as dictionary"""
        return {
            'cpu_cores': cls.CPU_CORES,
            'gpu_enabled': cls.GPU_ENABLED,
            'batch_size': cls.BATCH_SIZE,
            'max_workers': cls.MAX_WORKERS,
        }



"""Worker process management"""
import multiprocessing as mp
import threading
from typing import Callable, List, Any

class WorkerPool:
    """Manages a pool of worker processes"""
    
    def __init__(self, num_workers: int = None):
        self.num_workers = num_workers or mp.cpu_count()
        self.pool = mp.Pool(processes=self.num_workers)
        
    def map(self, func: Callable, iterable: List[Any]) -> List[Any]:
        """Map function over iterable using worker pool"""
        return self.pool.map(func, iterable)
    
    def close(self):
        """Close worker pool"""
        self.pool.close()
        self.pool.join()



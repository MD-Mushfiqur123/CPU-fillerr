"""Loss functions"""
import torch
import torch.nn as nn
from typing import Callable

def get_loss_function(name: str = 'cross_entropy') -> Callable:
    """Get loss function by name"""
    losses = {
        'cross_entropy': nn.CrossEntropyLoss(),
        'mse': nn.MSELoss(),
        'l1': nn.L1Loss(),
        'smooth_l1': nn.SmoothL1Loss(),
        'bce': nn.BCELoss(),
    }
    return losses.get(name.lower(), nn.CrossEntropyLoss())

class CombinedLoss(nn.Module):
    """Combined loss function"""
    def __init__(self, loss1: nn.Module, loss2: nn.Module, weight: float = 0.5):
        super().__init__()
        self.loss1 = loss1
        self.loss2 = loss2
        self.weight = weight
    
    def forward(self, pred, target):
        return self.weight * self.loss1(pred, target) + (1 - self.weight) * self.loss2(pred, target)



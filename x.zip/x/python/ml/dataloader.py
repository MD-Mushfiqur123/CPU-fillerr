"""Data loading utilities"""
import numpy as np
import torch
from torch.utils.data import Dataset, DataLoader
from typing import Tuple

class SyntheticDataset(Dataset):
    """Generate synthetic data for training"""
    
    def __init__(self, size: int = 10000, input_dim: int = 784, output_dim: int = 10):
        self.size = size
        self.input_dim = input_dim
        self.output_dim = output_dim
        self.data = np.random.randn(size, input_dim).astype(np.float32)
        self.labels = np.random.randint(0, output_dim, size).astype(np.int64)
    
    def __len__(self):
        return self.size
    
    def __getitem__(self, idx):
        return torch.tensor(self.data[idx]), torch.tensor(self.labels[idx])

class DataLoaderFactory:
    """Factory for creating data loaders"""
    
    @staticmethod
    def create_loader(dataset: Dataset, batch_size: int = 32, shuffle: bool = True):
        return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle, num_workers=4)



"""FastAPI server"""
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
import asyncio
from typing import Dict

app = FastAPI(title="Ultra Heavy Compute API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "Ultra Heavy Compute Platform"}

@app.post("/compute")
async def compute_endpoint(data: Dict):
    """Heavy computation endpoint"""
    result = 0.0
    for i in range(10000000):
        result += i * 0.0001
    return {"result": result}

@app.post("/matrix")
async def matrix_endpoint(size: int = 1000):
    """Matrix multiplication endpoint"""
    import numpy as np
    a = np.random.randn(size, size)
    b = np.random.randn(size, size)
    result = np.dot(a, b)
    return {"size": size, "computed": True}



"""API routes"""
from fastapi import APIRouter
from typing import List

router = APIRouter()

@router.get("/health")
async def health_check():
    return {"status": "healthy"}

@router.get("/stats")
async def get_stats():
    import psutil
    return {
        "cpu_percent": psutil.cpu_percent(interval=1),
        "memory_percent": psutil.virtual_memory().percent,
    }

@router.post("/batch")
async def batch_process(items: List[dict]):
    """Batch processing endpoint"""
    results = []
    for item in items:
        # Heavy computation per item
        result = sum(i**2 for i in range(100000))
        results.append({"item": item, "result": result})
    return {"results": results}



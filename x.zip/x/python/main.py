#!/usr/bin/env python3
"""Main entry point for Python compute platform"""
import asyncio
import multiprocessing as mp
from python.core.config import Config
from python.core.logger import setup_logger
from python.api.server import app
import uvicorn

logger = setup_logger(__name__)

def run_heavy_compute():
    """Run heavy computation to use all CPU/GPU"""
    import numpy as np
    import torch
    
    logger.info(f"Starting heavy computation on {Config.CPU_CORES} cores")
    
    # CPU intensive
    processes = []
    for _ in range(Config.CPU_CORES):
        p = mp.Process(target=cpu_worker)
        p.start()
        processes.append(p)
    
    # GPU intensive
    if Config.GPU_ENABLED and torch.cuda.is_available():
        logger.info("Starting GPU computation...")
        gpu_worker()
    
    # Wait for all processes
    for p in processes:
        p.join()

def cpu_worker():
    """CPU worker process"""
    import numpy as np
    while True:
        arr = np.random.randn(10000, 10000)
        result = np.dot(arr, arr)
        del arr, result

def gpu_worker():
    """GPU worker"""
    import torch
    device = torch.device('cuda')
    while True:
        x = torch.randn(10000, 10000, device=device)
        y = torch.matmul(x, x)
        del x, y

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == 'compute':
        run_heavy_compute()
    else:
        uvicorn.run(app, host="0.0.0.0", port=8000)


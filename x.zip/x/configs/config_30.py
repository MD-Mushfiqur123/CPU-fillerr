// Config 30
CONFIG_30 = True

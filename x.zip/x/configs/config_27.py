// Config 27
CONFIG_27 = True

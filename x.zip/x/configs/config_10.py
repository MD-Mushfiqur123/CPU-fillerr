// Config 10
CONFIG_10 = True

// Config 24
CONFIG_24 = True

// Config 40
CONFIG_40 = True

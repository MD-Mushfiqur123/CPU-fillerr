// Config 36
CONFIG_36 = True

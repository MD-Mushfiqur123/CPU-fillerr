// Config 23
CONFIG_23 = True

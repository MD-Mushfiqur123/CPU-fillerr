// Config 25
CONFIG_25 = True

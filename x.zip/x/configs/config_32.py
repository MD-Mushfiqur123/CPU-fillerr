// Config 32
CONFIG_32 = True

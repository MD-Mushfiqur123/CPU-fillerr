// Config 26
CONFIG_26 = True

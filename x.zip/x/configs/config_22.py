// Config 22
CONFIG_22 = True

// Config 6
CONFIG_6 = True

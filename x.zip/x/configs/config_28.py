// Config 28
CONFIG_28 = True

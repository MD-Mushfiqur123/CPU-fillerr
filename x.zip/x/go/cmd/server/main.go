package main

import (
	"fmt"
	"log"
	"net/http"
	"runtime"
	"time"
	
	"github.com/gin-gonic/gin"
)

func main() {
	r := gin.Default()
	
	r.GET("/health", healthCheck)
	r.POST("/compute", heavyCompute)
	r.POST("/matrix", matrixMultiply)
	
	port := ":8080"
	fmt.Printf("Go server starting on %s\n", port)
	log.Fatal(http.ListenAndServe(port, r))
}

func healthCheck(c *gin.Context) {
	c.JSON(http.StatusOK, gin.H{
		"status":    "ok",
		"goroutines": runtime.NumGoroutine(),
		"cpu_cores": runtime.NumCPU(),
	})
}

func heavyCompute(c *gin.Context) {
	start := time.Now()
	
	// Heavy computation using all CPU cores
	result := 0.0
	numWorkers := runtime.NumCPU() * 2
	
	results := make(chan float64, numWorkers)
	for i := 0; i < numWorkers; i++ {
		go func() {
			sum := 0.0
			for j := 0; j < 10000000; j++ {
				sum += float64(j) * 0.001
			}
			results <- sum
		}()
	}
	
	for i := 0; i < numWorkers; i++ {
		result += <-results
	}
	
	duration := time.Since(start)
	c.JSON(http.StatusOK, gin.H{
		"result":   result,
		"duration": duration.String(),
	})
}

func matrixMultiply(c *gin.Context) {
	size := 1000
	a := make([][]float64, size)
	b := make([][]float64, size)
	
	for i := range a {
		a[i] = make([]float64, size)
		b[i] = make([]float64, size)
		for j := range a[i] {
			a[i][j] = float64(i + j)
			b[i][j] = float64(i - j)
		}
	}
	
	result := make([][]float64, size)
	for i := range result {
		result[i] = make([]float64, size)
	}
	
	start := time.Now()
	for i := 0; i < size; i++ {
		for j := 0; j < size; j++ {
			for k := 0; k < size; k++ {
				result[i][j] += a[i][k] * b[k][j]
			}
		}
	}
	duration := time.Since(start)
	
	c.JSON(http.StatusOK, gin.H{
		"size":     size,
		"duration": duration.String(),
	})
}



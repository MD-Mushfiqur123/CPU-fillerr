package service
func Service25() string { return "service25" }

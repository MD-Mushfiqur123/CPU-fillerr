package service

import (
	"context"
	"sync"
)

type Worker struct {
	ID     string
	Status string
	mu     sync.Mutex
}

type WorkerPool struct {
	workers []*Worker
	mu      sync.RWMutex
}

func NewWorkerPool(size int) *WorkerPool {
	workers := make([]*Worker, size)
	for i := 0; i < size; i++ {
		workers[i] = &Worker{
			ID:     string(rune(i + 'A')),
			Status: "idle",
		}
	}
	return &WorkerPool{workers: workers}
}

func (wp *WorkerPool) GetWorker() *Worker {
	wp.mu.Lock()
	defer wp.mu.Unlock()
	
	for _, w := range wp.workers {
		if w.Status == "idle" {
			w.mu.Lock()
			w.Status = "busy"
			w.mu.Unlock()
			return w
		}
	}
	return nil
}

func (w *Worker) Release() {
	w.mu.Lock()
	defer w.mu.Unlock()
	w.Status = "idle"
}

func (wp *WorkerPool) Execute(ctx context.Context, task func()) error {
	worker := wp.GetWorker()
	if worker == nil {
		return ErrNoWorkerAvailable
	}
	defer worker.Release()
	
	task()
	return nil
}

var ErrNoWorkerAvailable = &WorkerError{Message: "no worker available"}

type WorkerError struct {
	Message string
}

func (e *WorkerError) Error() string {
	return e.Message
}


package service
func Service2() string { return "service2" }

package service
func Service1() string { return "service1" }

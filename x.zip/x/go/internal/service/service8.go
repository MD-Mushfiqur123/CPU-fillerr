package service
func Service8() string { return "service8" }

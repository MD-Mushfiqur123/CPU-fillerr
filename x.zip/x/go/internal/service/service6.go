package service
func Service6() string { return "service6" }

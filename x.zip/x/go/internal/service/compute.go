package service

import (
	"math"
	"runtime"
	"sync"
	"time"
)

type ComputeService struct {
	activeTasks int
	mu          sync.Mutex
}

func NewComputeService() *ComputeService {
	return &ComputeService{}
}

func (s *ComputeService) DoCompute(operation string, data interface{}) interface{} {
	s.mu.Lock()
	s.activeTasks++
	s.mu.Unlock()
	defer func() {
		s.mu.Lock()
		s.activeTasks--
		s.mu.Unlock()
	}()
	
	switch operation {
	case "heavy":
		return s.heavyCompute(10000000)
	case "matrix":
		return s.matrixMultiply(1000)
	default:
		return map[string]string{"error": "unknown operation"}
	}
}

func (s *ComputeService) heavyCompute(iterations int) float64 {
	result := 0.0
	for i := 0; i < iterations; i++ {
		result += math.Sqrt(float64(i)) * math.Log(float64(i+1))
	}
	return result
}

func (s *ComputeService) matrixMultiply(size int) map[string]interface{} {
	a := make([][]float64, size)
	b := make([][]float64, size)
	
	for i := range a {
		a[i] = make([]float64, size)
		b[i] = make([]float64, size)
		for j := range a[i] {
			a[i][j] = float64(i + j)
			b[i][j] = float64(i - j)
		}
	}
	
	result := make([][]float64, size)
	for i := range result {
		result[i] = make([]float64, size)
	}
	
	start := time.Now()
	
	var wg sync.WaitGroup
	numWorkers := runtime.NumCPU()
	chunkSize := size / numWorkers
	
	for w := 0; w < numWorkers; w++ {
		wg.Add(1)
		go func(startRow, endRow int) {
			defer wg.Done()
			for i := startRow; i < endRow; i++ {
				for j := 0; j < size; j++ {
					for k := 0; k < size; k++ {
						result[i][j] += a[i][k] * b[k][j]
					}
				}
			}
		}(w*chunkSize, (w+1)*chunkSize)
	}
	
	wg.Wait()
	duration := time.Since(start)
	
	return map[string]interface{}{
		"size":     size,
		"duration": duration.String(),
	}
}

func (s *ComputeService) GetStats() map[string]interface{} {
	var m runtime.MemStats
	runtime.ReadMemStats(&m)
	
	return map[string]interface{}{
		"goroutines":  runtime.NumGoroutine(),
		"cpu_cores":   runtime.NumCPU(),
		"active_tasks": s.activeTasks,
		"mem_alloc":   m.Alloc,
	}
}


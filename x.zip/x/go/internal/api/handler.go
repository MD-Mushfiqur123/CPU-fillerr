package api

import (
	"encoding/json"
	"net/http"
)

type Handler struct {
	computeService ComputeService
}

func NewHandler(cs ComputeService) *Handler {
	return &Handler{computeService: cs}
}

func (h *Handler) HealthCheck(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{"status": "ok"})
}

func (h *Handler) Compute(w http.ResponseWriter, r *http.Request) {
	var req ComputeRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	
	result := h.computeService.DoCompute(req.Operation, req.Data)
	
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(result)
}

type ComputeRequest struct {
	Operation string      `json:"operation"`
	Data      interface{} `json:"data"`
}


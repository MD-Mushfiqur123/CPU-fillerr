package api

import (
	"github.com/gin-gonic/gin"
)

func SetupRouter(handler *Handler) *gin.Engine {
	r := gin.Default()
	
	r.GET("/health", handler.HealthCheck)
	r.POST("/compute", handler.Compute)
	r.GET("/stats", handler.GetStats)
	
	return r
}

func (h *Handler) GetStats(c *gin.Context) {
	stats := h.computeService.GetStats()
	c.JSON(200, stats)
}


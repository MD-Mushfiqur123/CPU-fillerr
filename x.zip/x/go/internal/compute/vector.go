package compute

import (
	"math"
)

func DotProduct(a, b []float64) float64 {
	if len(a) != len(b) {
		return 0
	}
	
	result := 0.0
	for i := range a {
		result += a[i] * b[i]
	}
	return result
}

func VectorNorm(v []float64) float64 {
	sum := 0.0
	for _, x := range v {
		sum += x * x
	}
	return math.Sqrt(sum)
}

func VectorAdd(a, b []float64) []float64 {
	if len(a) != len(b) {
		return nil
	}
	
	result := make([]float64, len(a))
	for i := range a {
		result[i] = a[i] + b[i]
	}
	return result
}

func VectorScale(v []float64, scalar float64) []float64 {
	result := make([]float64, len(v))
	for i := range v {
		result[i] = v[i] * scalar
	}
	return result
}


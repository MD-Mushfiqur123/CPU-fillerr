package compute

import (
	"sync"
)

func MultiplyMatrices(a, b [][]float64) [][]float64 {
	n := len(a)
	m := len(b[0])
	p := len(b)
	
	result := make([][]float64, n)
	for i := range result {
		result[i] = make([]float64, m)
	}
	
	var wg sync.WaitGroup
	numWorkers := 4
	
	for t := 0; t < numWorkers; t++ {
		wg.Add(1)
		go func(threadID int) {
			defer wg.Done()
			for i := threadID; i < n; i += numWorkers {
				for j := 0; j < m; j++ {
					for k := 0; k < p; k++ {
						result[i][j] += a[i][k] * b[k][j]
					}
				}
			}
		}(t)
	}
	
	wg.Wait()
	return result
}

func AddMatrices(a, b [][]float64) [][]float64 {
	n := len(a)
	m := len(a[0])
	result := make([][]float64, n)
	
	for i := range result {
		result[i] = make([]float64, m)
		for j := range result[i] {
			result[i][j] = a[i][j] + b[i][j]
		}
	}
	
	return result
}


#include "performance.h"
#include <chrono>
#include <thread>
#include <vector>

namespace performance {
    
    Timer::Timer() : start_time(std::chrono::high_resolution_clock::now()) {}
    
    void Timer::reset() {
        start_time = std::chrono::high_resolution_clock::now();
    }
    
    double Timer::elapsed_ms() const {
        auto end_time = std::chrono::high_resolution_clock::now();
        auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(
            end_time - start_time
        );
        return duration.count();
    }
    
    void parallel_for(int start, int end, std::function<void(int)> func, int num_threads) {
        if (num_threads <= 0) {
            num_threads = std::thread::hardware_concurrency();
        }
        
        std::vector<std::thread> threads;
        int chunk_size = (end - start) / num_threads;
        
        for (int t = 0; t < num_threads; ++t) {
            int chunk_start = start + t * chunk_size;
            int chunk_end = (t == num_threads - 1) ? end : start + (t + 1) * chunk_size;
            
            threads.emplace_back([=]() {
                for (int i = chunk_start; i < chunk_end; ++i) {
                    func(i);
                }
            });
        }
        
        for (auto& thread : threads) {
            thread.join();
        }
    }
    
    void cpu_intensive_work(int iterations) {
        double result = 0.0;
        for (int i = 0; i < iterations; ++i) {
            result += std::sin(i) * std::cos(i) * std::sqrt(i);
        }
    }
}


#ifndef PERFORMANCE_H
#define PERFORMANCE_H

#include <chrono>
#include <functional>

namespace performance {
    
    class Timer {
    public:
        Timer();
        void reset();
        double elapsed_ms() const;
        
    private:
        std::chrono::high_resolution_clock::time_point start_time;
    };
    
    void parallel_for(int start, int end, std::function<void(int)> func, int num_threads = 0);
    void cpu_intensive_work(int iterations);
}

#endif


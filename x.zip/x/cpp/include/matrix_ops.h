#ifndef MATRIX_OPS_H
#define MATRIX_OPS_H

#include <vector>

std::vector<std::vector<double>> multiplyMatrices(
    const std::vector<std::vector<double>>& a,
    const std::vector<std::vector<double>>& b
);

std::vector<std::vector<double>> addMatrices(
    const std::vector<std::vector<double>>& a,
    const std::vector<std::vector<double>>& b
);

double computeDeterminant(const std::vector<std::vector<double>>& matrix);

#endif



#include <iostream>
void compute22() { }

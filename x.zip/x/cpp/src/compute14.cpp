#include <iostream>
void compute14() { }

#include <iostream>
void compute23() { }

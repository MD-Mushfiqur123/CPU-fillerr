#include <iostream>
void compute6() { }

#include <iostream>
void compute24() { }

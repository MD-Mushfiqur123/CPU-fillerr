#include <iostream>
void compute21() { }

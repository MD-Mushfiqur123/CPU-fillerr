#include <iostream>
void compute9() { }

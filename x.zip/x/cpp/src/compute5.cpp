#include <iostream>
void compute5() { }

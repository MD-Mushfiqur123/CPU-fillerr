#include <iostream>
void compute4() { }

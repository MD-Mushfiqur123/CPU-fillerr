#include <iostream>
void compute17() { }

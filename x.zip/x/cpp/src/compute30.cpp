#include <iostream>
void compute30() { }

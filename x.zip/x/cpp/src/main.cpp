#include <iostream>
#include <vector>
#include <thread>
#include <chrono>
#include <cmath>
#include "matrix_ops.h"

int main(int argc, char** argv) {
    std::cout << "Ultra-Heavy C++ Compute Engine" << std::endl;
    
    const int size = 2000;
    std::vector<std::vector<double>> matrix1(size, std::vector<double>(size));
    std::vector<std::vector<double>> matrix2(size, std::vector<double>(size));
    
    // Initialize matrices with random values
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            matrix1[i][j] = static_cast<double>(rand()) / RAND_MAX;
            matrix2[i][j] = static_cast<double>(rand()) / RAND_MAX;
        }
    }
    
    // Heavy computation
    auto start = std::chrono::high_resolution_clock::now();
    auto result = multiplyMatrices(matrix1, matrix2);
    auto end = std::chrono::high_resolution_clock::now();
    
    auto duration = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << "Computation completed in " << duration.count() << " ms" << std::endl;
    
    return 0;
}



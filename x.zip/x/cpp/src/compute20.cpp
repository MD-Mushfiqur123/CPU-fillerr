#include <iostream>
void compute20() { }

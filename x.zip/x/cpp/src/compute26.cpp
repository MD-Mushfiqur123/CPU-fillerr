#include <iostream>
void compute26() { }

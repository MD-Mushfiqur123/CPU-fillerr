#include <iostream>
void compute1() { }

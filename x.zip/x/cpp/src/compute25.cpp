#include <iostream>
void compute25() { }

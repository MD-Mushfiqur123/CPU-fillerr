#include <iostream>
void compute18() { }

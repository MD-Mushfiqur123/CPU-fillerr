#include <iostream>
void compute3() { }

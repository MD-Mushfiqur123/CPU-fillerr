#include <iostream>
void compute16() { }

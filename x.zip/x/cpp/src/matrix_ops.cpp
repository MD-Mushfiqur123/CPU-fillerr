#include "matrix_ops.h"
#include <cmath>
#include <thread>
#include <algorithm>

std::vector<std::vector<double>> multiplyMatrices(
    const std::vector<std::vector<double>>& a,
    const std::vector<std::vector<double>>& b) {
    
    int n = a.size();
    int m = b[0].size();
    int p = b.size();
    
    std::vector<std::vector<double>> result(n, std::vector<double>(m, 0.0));
    
    // Parallel matrix multiplication
    std::vector<std::thread> threads;
    int num_threads = std::thread::hardware_concurrency();
    
    for (int t = 0; t < num_threads; ++t) {
        threads.emplace_back([&, t, num_threads]() {
            for (int i = t; i < n; i += num_threads) {
                for (int j = 0; j < m; ++j) {
                    for (int k = 0; k < p; ++k) {
                        result[i][j] += a[i][k] * b[k][j];
                    }
                }
            }
        });
    }
    
    for (auto& thread : threads) {
        thread.join();
    }
    
    return result;
}

std::vector<std::vector<double>> addMatrices(
    const std::vector<std::vector<double>>& a,
    const std::vector<std::vector<double>>& b) {
    
    int n = a.size();
    int m = a[0].size();
    std::vector<std::vector<double>> result(n, std::vector<double>(m));
    
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < m; ++j) {
            result[i][j] = a[i][j] + b[i][j];
        }
    }
    
    return result;
}

double computeDeterminant(const std::vector<std::vector<double>>& matrix) {
    int n = matrix.size();
    if (n == 1) return matrix[0][0];
    if (n == 2) return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
    
    double det = 0.0;
    for (int i = 0; i < n; ++i) {
        std::vector<std::vector<double>> submatrix(n - 1, std::vector<double>(n - 1));
        for (int j = 1; j < n; ++j) {
            for (int k = 0; k < n; ++k) {
                if (k < i) submatrix[j-1][k] = matrix[j][k];
                else if (k > i) submatrix[j-1][k-1] = matrix[j][k];
            }
        }
        det += (i % 2 == 0 ? 1 : -1) * matrix[0][i] * computeDeterminant(submatrix);
    }
    return det;
}



#include <iostream>
void compute15() { }

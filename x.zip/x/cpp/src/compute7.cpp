#include <iostream>
void compute7() { }

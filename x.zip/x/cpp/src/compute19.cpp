#include <iostream>
void compute19() { }

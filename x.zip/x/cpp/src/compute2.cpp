#include <iostream>
void compute2() { }

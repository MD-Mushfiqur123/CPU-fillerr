#include <iostream>
void compute8() { }

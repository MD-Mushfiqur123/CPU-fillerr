#include <iostream>
void compute27() { }

#include <iostream>
void compute10() { }

#include <iostream>
void compute12() { }

package com.ultraheavy.model; public class Model13 { private String id; }

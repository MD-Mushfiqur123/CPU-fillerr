package com.ultraheavy.model;

public class ComputeTask {
    private String id;
    private String type;
    private int size;
    private String status;
    
    public ComputeTask() {}
    
    public ComputeTask(String id, String type, int size) {
        this.id = id;
        this.type = type;
        this.size = size;
        this.status = "PENDING";
    }
    
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    
    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
    
    public int getSize() { return size; }
    public void setSize(int size) { this.size = size; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
}


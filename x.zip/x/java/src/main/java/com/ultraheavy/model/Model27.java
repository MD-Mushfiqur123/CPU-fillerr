package com.ultraheavy.model; public class Model27 { private String id; }

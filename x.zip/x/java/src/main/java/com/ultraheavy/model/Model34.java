package com.ultraheavy.model; public class Model34 { private String id; }

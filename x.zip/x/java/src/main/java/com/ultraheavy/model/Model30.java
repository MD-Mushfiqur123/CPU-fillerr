package com.ultraheavy.model; public class Model30 { private String id; }

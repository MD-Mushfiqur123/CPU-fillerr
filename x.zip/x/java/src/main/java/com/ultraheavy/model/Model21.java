package com.ultraheavy.model; public class Model21 { private String id; }

package com.ultraheavy.model; public class Model7 { private String id; }

package com.ultraheavy.api;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/api/v1")
public class ApiController {
    
    @GetMapping("/health")
    public ResponseEntity<String> health() {
        return ResponseEntity.ok("OK");
    }
    
    @GetMapping("/info")
    public ResponseEntity<Object> info() {
        return ResponseEntity.ok(new Object() {
            public final String version = "1.0.0";
            public final int cores = Runtime.getRuntime().availableProcessors();
        });
    }
}


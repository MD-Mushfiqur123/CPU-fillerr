package com.ultraheavy.model; public class Model45 { private String id; }

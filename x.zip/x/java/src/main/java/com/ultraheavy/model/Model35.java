package com.ultraheavy.model; public class Model35 { private String id; }

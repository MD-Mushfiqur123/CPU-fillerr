package com.ultraheavy.model; public class Model5 { private String id; }

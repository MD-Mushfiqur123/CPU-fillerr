package com.ultraheavy.model; public class Model24 { private String id; }

package com.ultraheavy.model; public class Model12 { private String id; }

package com.ultraheavy.model; public class Model25 { private String id; }

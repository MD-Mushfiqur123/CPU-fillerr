package com.ultraheavy.model; public class Model42 { private String id; }

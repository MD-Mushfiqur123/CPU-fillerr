package com.ultraheavy.model; public class Model18 { private String id; }

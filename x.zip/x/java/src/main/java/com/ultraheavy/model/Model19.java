package com.ultraheavy.model; public class Model19 { private String id; }

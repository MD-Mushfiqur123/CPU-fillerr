package com.ultraheavy.model; public class Model49 { private String id; }

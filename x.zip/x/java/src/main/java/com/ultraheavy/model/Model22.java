package com.ultraheavy.model; public class Model22 { private String id; }

package com.ultraheavy.model; public class Model17 { private String id; }

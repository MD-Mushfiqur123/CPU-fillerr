package com.ultraheavy.model; public class Model20 { private String id; }

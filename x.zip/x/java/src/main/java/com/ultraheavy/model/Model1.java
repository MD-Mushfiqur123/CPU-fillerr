package com.ultraheavy.model; public class Model1 { private String id; }

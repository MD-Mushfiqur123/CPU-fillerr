package com.ultraheavy.model; public class Model38 { private String id; }

package com.ultraheavy.model; public class Model3 { private String id; }

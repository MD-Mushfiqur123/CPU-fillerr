package com.ultraheavy.model; public class Model36 { private String id; }

package com.ultraheavy.model; public class Model40 { private String id; }

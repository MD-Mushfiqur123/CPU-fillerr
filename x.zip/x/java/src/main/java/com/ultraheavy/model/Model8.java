package com.ultraheavy.model; public class Model8 { private String id; }

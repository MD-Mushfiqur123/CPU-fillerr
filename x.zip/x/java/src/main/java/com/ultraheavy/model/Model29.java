package com.ultraheavy.model; public class Model29 { private String id; }

package com.ultraheavy.model; public class Model31 { private String id; }

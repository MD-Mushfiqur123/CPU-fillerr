package com.ultraheavy.model; public class Model48 { private String id; }

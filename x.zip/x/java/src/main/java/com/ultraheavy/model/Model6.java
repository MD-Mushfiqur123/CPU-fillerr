package com.ultraheavy.model; public class Model6 { private String id; }

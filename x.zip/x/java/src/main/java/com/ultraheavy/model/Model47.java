package com.ultraheavy.model; public class Model47 { private String id; }

package com.ultraheavy.model; public class Model4 { private String id; }

package com.ultraheavy.model; public class Model23 { private String id; }

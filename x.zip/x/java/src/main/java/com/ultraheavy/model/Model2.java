package com.ultraheavy.model; public class Model2 { private String id; }

package com.ultraheavy.model; public class Model50 { private String id; }

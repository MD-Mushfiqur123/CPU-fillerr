package com.ultraheavy.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import java.util.*;

@RestController
@RequestMapping("/api/compute")
public class ComputeController {
    
    @PostMapping("/matrix")
    public ResponseEntity<Map<String, Object>> multiplyMatrix(@RequestParam int size) {
        double[][] a = new double[size][size];
        double[][] b = new double[size][size];
        
        // Initialize matrices
        Random rand = new Random();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                a[i][j] = rand.nextDouble();
                b[i][j] = rand.nextDouble();
            }
        }
        
        // Multiply matrices
        double[][] result = new double[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                for (int k = 0; k < size; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        
        Map<String, Object> response = new HashMap<>();
        response.put("size", size);
        response.put("computed", true);
        return ResponseEntity.ok(response);
    }
    
    @PostMapping("/heavy")
    public ResponseEntity<Map<String, Object>> heavyCompute() {
        long start = System.currentTimeMillis();
        double result = 0.0;
        for (int i = 0; i < 100000000; i++) {
            result += Math.sin(i) * Math.cos(i);
        }
        long duration = System.currentTimeMillis() - start;
        
        Map<String, Object> response = new HashMap<>();
        response.put("result", result);
        response.put("duration", duration);
        return ResponseEntity.ok(response);
    }
}



package com.ultraheavy.model; public class Model46 { private String id; }

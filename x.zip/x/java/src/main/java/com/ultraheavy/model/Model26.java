package com.ultraheavy.model; public class Model26 { private String id; }

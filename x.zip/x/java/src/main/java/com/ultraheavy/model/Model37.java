package com.ultraheavy.model; public class Model37 { private String id; }

package com.ultraheavy.service;

import org.springframework.stereotype.Service;
import java.util.concurrent.*;

@Service
public class ComputeService {
    
    private final ExecutorService executor = Executors.newFixedThreadPool(
        Runtime.getRuntime().availableProcessors() * 2
    );
    
    public CompletableFuture<Double> heavyComputation(int iterations) {
        return CompletableFuture.supplyAsync(() -> {
            double result = 0.0;
            for (int i = 0; i < iterations; i++) {
                result += Math.sqrt(i) * Math.log(i + 1);
            }
            return result;
        }, executor);
    }
    
    public double[][] matrixMultiply(double[][] a, double[][] b) {
        int n = a.length;
        double[][] result = new double[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return result;
    }
}

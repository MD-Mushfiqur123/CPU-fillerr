package com.ultraheavy.model; public class Model15 { private String id; }

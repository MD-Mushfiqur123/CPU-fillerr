package com.ultraheavy.model; public class Model32 { private String id; }

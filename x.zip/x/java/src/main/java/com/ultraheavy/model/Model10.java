package com.ultraheavy.model; public class Model10 { private String id; }

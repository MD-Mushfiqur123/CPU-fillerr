package com.ultraheavy.model; public class Model33 { private String id; }

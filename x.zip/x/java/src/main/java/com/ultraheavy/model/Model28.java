package com.ultraheavy.model; public class Model28 { private String id; }
